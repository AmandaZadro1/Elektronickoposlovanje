# My2auth

Simple Android app built in Java which implement Firebase Phone Authentication using OTP.
Through app you can:

1) Firebase Phone Authentication
2) Handle OTP / Verification Code
3) Resend OTP / Verification Code
4) Show Logged In User | Profile
